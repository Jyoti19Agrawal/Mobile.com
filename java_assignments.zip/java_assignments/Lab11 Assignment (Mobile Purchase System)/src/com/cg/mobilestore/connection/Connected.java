package com.cg.mobilestore.connection;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Connected {

	public static Connection getConnected() {
		Connection conn = null;
		try {
			Properties prop = new Properties();
			InputStream is = Connection.class.getClassLoader()
					.getResourceAsStream("database.properties");
			prop.load(is);
			Class.forName(prop.getProperty("driver"));

			conn = DriverManager.getConnection(prop.getProperty("connUrl"),
					prop.getProperty("userName"), prop.getProperty("password"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}