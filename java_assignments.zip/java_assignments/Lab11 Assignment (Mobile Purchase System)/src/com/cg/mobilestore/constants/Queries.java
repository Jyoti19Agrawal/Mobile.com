package com.cg.mobilestore.constants;

public class Queries {

	public static final String INSERTSQL = "insert into purchasedetails values(?,?,?,?,sysdate,?)";

	public static final String UPDATESQL = "update mobiles set quantity=quantity-1 where mobileid=?";

	public static final String DELETESQL = "delete from  purchasedetails where mobileid=?";

	public static final String SEARCHSQL = "select * from  mobiles where price<=?";

	public static final String VIEWSQL = "select * from  mobiles where quantity>0";

}
