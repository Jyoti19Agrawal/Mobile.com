package com.cg.mobilestore.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobilestore.dao.IMobileDAO;
import com.cg.mobilestore.dao.MobileDAOImpl;
import com.cg.mobilestore.dto.MobileDetails;
import com.cg.mobilestore.dto.PurchaseDetails;
import com.cg.mobilestore.exception.IdNotFoundException;
import com.cg.mobilestore.exception.NoDataFoundException;

public class MobileServiceImpl implements IMobileService {

	// function to insert data
	@Override
	public int insertData(PurchaseDetails pd) throws IdNotFoundException {

		IMobileDAO mdi = new MobileDAOImpl();
		return mdi.insertData(pd);

	}

	// function to delete data
	@Override
	public void deleteData(PurchaseDetails pd) {

		IMobileDAO mdi = new MobileDAOImpl();
		mdi.deleteData(pd);

	}

	@Override
	public void priceBasedData(MobileDetails md) {

		IMobileDAO mdi = new MobileDAOImpl();
		mdi.priceBasedData(md);

	}

	// viewing of records
	@Override
	public void viewMobilesRecord() throws NoDataFoundException {

		IMobileDAO mdi = new MobileDAOImpl();
		mdi.viewMobilesRecord();
	}

	// validation of details
	@Override
	public boolean validateCustomerName(String customerName) {
		return Pattern.matches("[A-Z]{1}[A-Za-z]{1,19}", customerName);
	}

	@Override
	public boolean validateMailId(String mailId) {
		String emailRegex = "[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
		Pattern pattern = Pattern.compile(emailRegex, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(mailId);
		if (matcher.matches())
			return true;
		else
			return false;
	}

	@Override
	public boolean validateMobileId(int mobileId) {
		return Pattern.matches("[0-9]{4}", mobileId + "");
	}

	@Override
	public boolean validatePhoneNo(String phoneNo) {
		return Pattern.matches("[789]{1}[0-9]{9}", phoneNo);
	}

	public boolean validatePurchaseDetails(PurchaseDetails pd) {
		if (pd.getcName().equals("Sushil")) {
			return true;
		} else {
			return false;
		}
	}

}
