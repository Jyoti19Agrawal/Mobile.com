package com.cg.mobilestore.service;

import com.cg.mobilestore.dto.MobileDetails;
import com.cg.mobilestore.dto.PurchaseDetails;
import com.cg.mobilestore.exception.IdNotFoundException;
import com.cg.mobilestore.exception.NoDataFoundException;

public interface IMobileService {

	public int insertData(PurchaseDetails pd) throws IdNotFoundException;

	public void deleteData(PurchaseDetails pd);

	public void priceBasedData(MobileDetails md);

	public void viewMobilesRecord() throws NoDataFoundException;

	public boolean validateCustomerName(String customerName);

	public boolean validateMailId(String mailId);

	public boolean validatePhoneNo(String phoneNo);

	boolean validateMobileId(int mobileId);

	public boolean validatePurchaseDetails(PurchaseDetails pd);

}
