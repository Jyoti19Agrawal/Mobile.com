package com.cg.mobilestore.dao;

import com.cg.mobilestore.dto.MobileDetails;
import com.cg.mobilestore.dto.PurchaseDetails;
import com.cg.mobilestore.exception.IdNotFoundException;
import com.cg.mobilestore.exception.NoDataFoundException;

public interface IMobileDAO {

	public int insertData(PurchaseDetails pd) throws IdNotFoundException;

	public void deleteData(PurchaseDetails pd);

	public void priceBasedData(MobileDetails md);

	public void viewMobilesRecord() throws NoDataFoundException;

}
