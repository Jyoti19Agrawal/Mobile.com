package com.cg.mobilestore.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.mobilestore.constants.Queries;
import com.cg.mobilestore.dto.MobileDetails;
import com.cg.mobilestore.dto.PurchaseDetails;
import com.cg.mobilestore.exception.IdNotFoundException;
import com.cg.mobilestore.exception.NoDataFoundException;

public class MobileDAOImpl implements IMobileDAO {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	Statement st = null;

	@Override
	public int insertData(PurchaseDetails pd) throws IdNotFoundException {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "PRAKHARGUPTA",
					"orcl");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(conn);
		int flag = 0;
		try {
			String sql = "select mobileid from mobiles";
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				if (rs.getInt("mobileid") == pd.getMobileId())
					flag = 1;
			}
			if (flag == 0)
				throw new IdNotFoundException("Id does not exists");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		if (flag == 1) {
			try {
				stat = conn.prepareStatement(Queries.INSERTSQL);

				stat.setInt(1, pd.getPurchaseId());
				stat.setString(2, pd.getcName());
				stat.setString(3, pd.getMailId());
				stat.setString(4, pd.getPhoneNo());
				stat.setInt(5, pd.getMobileId());
				stat.executeQuery();
				PreparedStatement stat1 = conn
						.prepareStatement(Queries.UPDATESQL);
				stat1.setInt(1, pd.getMobileId());
				if (stat1.executeQuery() != null) {
					System.out.println("data inserted successfully");
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return flag;
	}

	@Override
	public void deleteData(PurchaseDetails pd) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "PRAKHARGUPTA",
					"orcl");

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(conn);
		try {
			stat = conn.prepareStatement(Queries.DELETESQL);
			stat.setInt(1, pd.getMobileId());
			stat.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void priceBasedData(MobileDetails md) {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "PRAKHARGUPTA",
					"orcl");

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(conn);
		try {
			stat = conn.prepareStatement(Queries.SEARCHSQL);
			stat.setFloat(1, md.getPrice());
			rs = stat.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getInt("mobileId") + " "
						+ rs.getString("name") + " " + rs.getFloat("price")
						+ " " + rs.getInt("quantity"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void viewMobilesRecord() throws NoDataFoundException {

		int flag = 0;
		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "PRAKHARGUPTA",
					"orcl");

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(conn);
		try {
			stat = conn.prepareStatement(Queries.VIEWSQL);
			rs = stat.executeQuery();

			while (rs.next()) {
				flag = 1;
				System.out.println(rs.getInt("mobileId") + " "
						+ rs.getString("name") + " " + rs.getFloat("price")
						+ " " + rs.getInt("quantity"));

			}
			if (flag == 0) {
				throw new NoDataFoundException("No Data Exist in table");
			}

		} catch (

		SQLException e)

		{
			e.printStackTrace();
		}
	}
}
