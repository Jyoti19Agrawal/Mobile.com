package com.cg.mobilestore.exception;

public class NoDataFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	// creation of no data found exception function
	public NoDataFoundException(String msg) {
		super(msg);
	}

}
