package com.cg.mobilestore.exception;

public class IdNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	// creation of exception function
	public IdNotFoundException(String msg) {
		super(msg);
	}
}
