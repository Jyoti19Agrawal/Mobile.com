package com.cg.mobilestore.pesentation;

import java.util.Scanner;

import com.cg.mobilestore.dto.MobileDetails;
import com.cg.mobilestore.dto.PurchaseDetails;
import com.cg.mobilestore.exception.IdNotFoundException;
import com.cg.mobilestore.exception.NoDataFoundException;
import com.cg.mobilestore.service.IMobileService;
import com.cg.mobilestore.service.MobileServiceImpl;

public class MobileStorePresentation {

	static Scanner sc = new Scanner(System.in);
	static MobileDetails md = new MobileDetails();
	static PurchaseDetails pd = new PurchaseDetails();
	static IMobileService ms = new MobileServiceImpl();

	public static void main(String[] args) {

		while (true) {
			System.out.println();
			System.out
					.println("\nWelcome to Mobile Purchase System \n1.Place Order \n2.View Mobile Details \n3.Delete Mobile Record \n4.Search for Mobile \nEnter Your Choice");
			int ch = sc.nextInt();

			// choice of options
			switch (ch) {
			case 1:
				placePurchaseOrder();
				break;

			case 2:
				displayMobileList();
				break;

			case 3:
				acceptMobileId();
				break;

			case 4:
				searchMobileId();
				break;

			case 0:
				exitApplication();
				break;

			default:
				System.out.println("Wrong Input");
			}
		}
	}

	private static PurchaseDetails acceptPurchaseDetails() {

		String customerName, mailId, phoneNo;
		int mobileId, purchaseId;

		System.out.println("Enter PurchaseId");
		purchaseId = sc.nextInt();
		pd.setPurchaseId(purchaseId);

		// accepting customer name
		System.out.println("Enter customer name");
		customerName = sc.next();
		while (true) {
			if (ms.validateCustomerName(customerName)) {
				pd.setcName(customerName);
				break;
			} else {
				System.out.println("Enter Valid Customer Name");
				customerName = sc.next();
			}
		}

		// accepting customer email Id
		System.out.println("Enter email");
		mailId = sc.next();
		while (true) {
			if (ms.validateMailId(mailId)) {
				pd.setMailId(mailId);
				break;
			} else {
				System.out.println("Enter valid Customer's Email Id");
				mailId = sc.next();
			}
		}

		// accepting Phone number
		System.out.println("Enter Customer's phoneNo");
		phoneNo = sc.next();
		while (true) {
			if (ms.validatePhoneNo(phoneNo)) {
				pd.setPhoneNo(phoneNo);
				break;
			} else {
				System.out.println("Enter valid Customer's PhoneNo");
				phoneNo = sc.next();
			}
		}

		// accepting mobileId
		System.out.println("Enter mobile id");
		mobileId = sc.nextInt();
		pd.setMobileId(mobileId);
		while (true) {
			if (ms.validateMobileId(mobileId)) {
				pd.setMobileId(mobileId);
				break;
			} else {
				System.out.println("Enter valid MobileId");
				mobileId = sc.nextInt();
			}
		}

		return pd;
	}

	private static void placePurchaseOrder() {
		IMobileService ms = new MobileServiceImpl();
		pd = acceptPurchaseDetails();
		try {
			ms.insertData(pd);
		} catch (IdNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void exitApplication() {
		System.out.println("Exit Mobile Order Application");
		System.out.println("============Thank You===========");
		System.exit(0);
	}

	private static void searchMobileId() {
		System.out.println("Enter the price range and get the mobile details");
		md.setPrice(sc.nextFloat());
		ms.priceBasedData(md);
	}

	private static void acceptMobileId() {
		System.out.println("Enter the mobileId you want to delete");
		pd.setMobileId(sc.nextInt());
		ms.deleteData(pd);
	}

	private static void displayMobileList() {
		System.out.println("Details of Mobiles Available in the shop");
		try {
			ms.viewMobilesRecord();
		} catch (NoDataFoundException e) {
			System.out.println(e.getMessage());
		}
	}
}
