package com.cg.mobilestore.test;

import static org.junit.Assert.*;

import com.cg.mobilestore.dto.PurchaseDetails;
import com.cg.mobilestore.exception.IdNotFoundException;
import com.cg.mobilestore.service.IMobileService;
import com.cg.mobilestore.service.MobileServiceImpl;

public class Test {

	@org.junit.Test
	public void testPlaceOrder() {
		PurchaseDetails pd = new PurchaseDetails();
		IMobileService ms = new MobileServiceImpl();
		pd.setcName("Anidh");
		pd.setMailId("ddd@gmail.com");
		pd.setPhoneNo("9898989898");
		pd.setMobileId(1001);
		try {
			assertEquals(1, ms.insertData(pd));
		} catch (IdNotFoundException e) {
			e.printStackTrace();
		}
	}

	@org.junit.Test
	public void testPlaceOrderNegative() {
		PurchaseDetails pd = new PurchaseDetails();
		IMobileService ms = new MobileServiceImpl();
		pd.setcName("Ani");
		pd.setMailId("defgmail.com");
		pd.setPhoneNo("9898989899");
		pd.setMobileId(1008);
		try {
			assertEquals(0, ms.insertData(pd));
		} catch (IdNotFoundException e) {
			e.printStackTrace();
		}
	}

}
